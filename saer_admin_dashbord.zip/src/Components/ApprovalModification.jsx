import React from "react";

function ApprovalModification() {
  return (
    <div className="px-5">
      <h1>Agency approved option</h1>
      <h1>Admin can change ID all information manually</h1>
      <h1>Delete ID can get back from admin panel</h1>
      <h1>Special tag option for any ID</h1>
    </div>
  );
}

export default ApprovalModification;
