import React from "react";

function CoinManagemen() {
  return (
    <div className="px-5">
      CoinManagemen
      <br />
      Master unlimited coin portal in admin panel that can give coin reseller id
      portal
      <br />
      Give option to admin panel to make any id for coin portal
      <br />
      ID coin history check option
    </div>
  );
}

export default CoinManagemen;
