import React from "react";

function ContentManagement() {
  return (
    <div className="px-5">
      ContentManagement
      <br />
      Mall item give manually to any user <br />
      Gift upload option
      <br />
      Mall item upload option
      <br />
      Profile background change option
      <br />
      Banner upload option
      <br />
      Any ID inbox check option
      <br />
      Game history check option
    </div>
  );
}

export default ContentManagement;
