import React from 'react'

function IDManagement() {
  return (
    <div className='px-5'>

<h1>I’d ban/unban option</h1>
      <h1>Manually user level up option</h1>
      <h1>Manually VIP give option to user id</h1>
      <h1>Special ID create option for mall special id</h1>
      <h1>Give any model or tag to any user from admin panel</h1>  



    </div>
  )
}

export default IDManagement