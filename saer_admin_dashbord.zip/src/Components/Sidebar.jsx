import React from "react";
import SidebarWork, { SidebarItem } from "./SidebarWork";
import { Icon } from "@iconify/react";

function Sidebar() {
  return (
    <div className="hidden md:flex">
      <SidebarWork>
        <SidebarItem
          icon={<Icon icon="carbon:id-management" width="24" />}
          text="ID Management"
          path="/dashbord/id"
        />
         <SidebarItem
          icon={<Icon icon="akar-icons:coin" width="24" />}
          text="Coin Management"
          path="/dashbord/coin"
        /> 
 <SidebarItem
          icon={<Icon  icon="mingcute:contacts-fill"  width="24" />}
          text="Content Management"
          path="/dashbord/contact"
        /> 
         <SidebarItem
          icon={<Icon icon="wpf:approval"  width="24" />}
          text="Approval & Modification"
          path="/dashbord/approva"
        />         

        
      </SidebarWork>
    </div>
  );
}

export default Sidebar;